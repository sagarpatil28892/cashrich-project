package com.cashrich.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cashrich.service.CoinService;

@RestController
@RequestMapping("/api/coins")
public class CoinController {

	@Autowired
	private CoinService coinService;

	@GetMapping("/latest")
	public ResponseEntity<String> getCoinData(@RequestParam Long userId) {
		if (userId == null || userId <= 0) {
			return new ResponseEntity<>("Invalid user ID provided.", HttpStatus.BAD_REQUEST);
		}

		try {
			String coinData = coinService.getCoinData(userId);
			return new ResponseEntity<>(coinData, HttpStatus.OK);
		} catch (RuntimeException e) {
			System.err.println("Error: " + e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			System.err.println("An unexpected error occurred: " + e.getMessage());
			return new ResponseEntity<>("An unexpected error occurred: " + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
