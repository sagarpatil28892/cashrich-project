package com.cashrich.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cashrich.dto.AuthRequest;
import com.cashrich.dto.AuthResponse;
import com.cashrich.dto.UserDTO;
import com.cashrich.service.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

	private final UserService userService;

	@Autowired
	public AuthController(UserService userService) {
		this.userService = userService;
	}

	@PostMapping("/signup")
	public ResponseEntity<UserDTO> signUpUser(@Valid @RequestBody UserDTO userDTO) {
		UserDTO createdUser = userService.signUpUser(userDTO);
		return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
	}

	@PostMapping("/login")
	public ResponseEntity<AuthResponse> loginUser(@Valid @RequestBody AuthRequest authRequest) {
		AuthResponse response = userService.loginUser(authRequest);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

}
