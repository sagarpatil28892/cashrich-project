package com.cashrich.serviceimpl;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cashrich.dto.UserDTO;
import com.cashrich.entity.CoinRequest;
import com.cashrich.entity.User;
import com.cashrich.repository.CoinRequestRepository;
import com.cashrich.repository.UserRepository;
import com.cashrich.service.CoinService;
import com.cashrich.service.UserService;

@Service
public class CoinServiceImpl implements CoinService {

	@Autowired
	private CoinRequestRepository coinRequestRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	@Value("${coin.api.key}")
	private String apiKey;

	private static final String COIN_API_URL = "https://api.coinmarketcap.com/v1/cryptocurrency/quotes/latest?symbol=BTC,ETHLTC";

	@Override
	public String getCoinData(Long userId) throws Exception {
		System.out.println("Fetching coin data for user ID: " + userId);

		UserDTO userDTO = userService.getUserById(userId);
		User user = userRepository.findById(userDTO.getId()).orElseThrow(() -> new RuntimeException("User not found"));

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();

		headers.set("X-CMC_PRO_API_KEY", apiKey);
		System.out.println("Using API Key: " + apiKey);

		HttpEntity<String> entity = new HttpEntity<>(headers);
		ResponseEntity<String> response = restTemplate.exchange(COIN_API_URL, HttpMethod.GET, entity, String.class);

		CoinRequest coinRequest = new CoinRequest();
		coinRequest.setUser(user);
		coinRequest.setResponse(response.getBody());
		coinRequest.setTimestamp(LocalDateTime.now());

		coinRequestRepository.save(coinRequest);
		return response.getBody();
	}
}
