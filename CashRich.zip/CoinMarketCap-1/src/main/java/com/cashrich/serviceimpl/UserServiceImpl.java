package com.cashrich.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cashrich.config.JwtUtil;
import com.cashrich.dto.AuthRequest;
import com.cashrich.dto.AuthResponse;
import com.cashrich.dto.UserDTO;
import com.cashrich.entity.User;
import com.cashrich.repository.UserRepository;
import com.cashrich.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;
	private final JwtUtil jwtUtil;

	@Autowired
	public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
		this.userRepository = userRepository;
		this.passwordEncoder = passwordEncoder;
		this.jwtUtil = jwtUtil;
	}

	@Override
	public UserDTO signUpUser(UserDTO userDTO) {
		if (userRepository.findByUsername(userDTO.getUserName()).isPresent()) {
			throw new IllegalArgumentException("Username already exists");
		}

		if (userRepository.findByEmail(userDTO.getEmail()).isPresent()) {
			throw new IllegalArgumentException("Email already exists");
		}

		User user = new User();
		user.setFirstName(userDTO.getFirstName());
		user.setLastName(userDTO.getLastName());
		user.setEmail(userDTO.getEmail());
		user.setMobile(userDTO.getMobile());
		user.setUsername(userDTO.getUserName());
		user.setPassword(passwordEncoder.encode(userDTO.getPassword()));

		User savedUser = userRepository.save(user);
		return convertToDTO(savedUser);
	}

	private UserDTO convertToDTO(User user) {
		UserDTO userDTO = new UserDTO();
		userDTO.setId(user.getId());
		userDTO.setFirstName(user.getFirstName());
		userDTO.setLastName(user.getLastName());
		userDTO.setEmail(user.getEmail());
		userDTO.setMobile(user.getMobile());
		userDTO.setUserName(user.getUsername());
		return userDTO;
	}

	@Override
	public AuthResponse loginUser(AuthRequest authRequest) {
		User user = userRepository.findByUsername(authRequest.getUsername())
				.orElseThrow(() -> new RuntimeException("User not found"));

		System.out.println("Found user: " + user.getUsername());

		boolean passwordMatch = passwordEncoder.matches(authRequest.getPassword(), user.getPassword());
		System.out.println("Password match result: " + passwordMatch);

		if (!passwordMatch) {
			throw new RuntimeException("Invalid credentials");
		}

		System.out.println("Password matched, generating token.");
		String token = jwtUtil.generateToken(user.getUsername());
		System.out.println("Generated token: " + token);

		AuthResponse authResponse = new AuthResponse();
		authResponse.setUserId(user.getId());
		authResponse.setUsername(user.getUsername());
		authResponse.setToken(token);

		return authResponse;
	}

	@Override
	public UserDTO updateUser(Long id, UserDTO userDTO) {
		User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));

		user.setFirstName(userDTO.getFirstName());
		user.setLastName(userDTO.getLastName());
		user.setMobile(userDTO.getMobile());

		if (userDTO.getPassword() != null && !userDTO.getPassword().isEmpty()) {
			user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
		}

		User updatedUser = userRepository.save(user);
		return convertToDTO(updatedUser);
	}

	@Override
	public void deleteUser(Long id) {
		userRepository.deleteById(id);
	}

	@Override
	public UserDTO getUserById(Long id) {
		User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
		return convertToDTO(user);
	}
}
