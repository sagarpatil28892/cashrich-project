package com.cashrich.service;

import com.cashrich.dto.AuthRequest;
import com.cashrich.dto.AuthResponse;
import com.cashrich.dto.UserDTO;

public interface UserService {
	UserDTO signUpUser(UserDTO userDTO);

	AuthResponse loginUser(AuthRequest authRequest);

	UserDTO updateUser(Long id, UserDTO userDTO);

	void deleteUser(Long id);

	UserDTO getUserById(Long id);
}
