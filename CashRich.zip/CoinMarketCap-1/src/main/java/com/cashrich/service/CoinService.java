package com.cashrich.service;

public interface CoinService {
	String getCoinData(Long userId) throws Exception;
}
