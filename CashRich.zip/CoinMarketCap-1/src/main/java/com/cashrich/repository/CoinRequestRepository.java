package com.cashrich.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cashrich.entity.CoinRequest;
import com.cashrich.entity.User;

public interface CoinRequestRepository extends JpaRepository<CoinRequest, Long> {
	List<CoinRequest> findByUser(User user);
}
